import warnings

warnings.filterwarnings("ignore")

import csv
import datetime
import json
import re
import sys

import requests
from bs4 import BeautifulSoup
from time import sleep
from collections.abc import Iterable
import urllib
import warnings
import time
import unittest

warnings.filterwarnings("ignore", category=DeprecationWarning)

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
from selenium import webdriver
from selenium.webdriver.support.ui import Select

from unidecode import unidecode

import pandas as pd

import itertools

# Colors
Purple = '\033[95m'
Blue = '\033[94m'
Cyan = '\033[96m'
Green = '\033[92m'
Yellow = '\033[93m'
Red = '\033[91m'
BOLD = '\033[1m'
UNDERLINE = '\033[4m'


class Product:
    def __init__(self, title, price, image, description, url, category,
                 images_list, brand, product_attributes, maintenance, product_spc, availability, image_name,
                 images_list_names, feedbacks, feedback_type,
                 created_at):
        self.title = title
        self.price = price
        self.image = image
        self.description = description
        self.url = url
        self.category = category
        self.images_list = images_list
        self.brand = brand
        self.product_attributes = product_attributes
        self.maintenance = maintenance
        self.product_spc = product_spc
        self.availability = availability
        self.image_name = image_name
        self.images_list_names = images_list_names
        self.feedbacks = feedbacks
        self.feedback_type = feedback_type
        self.created_at = created_at


class URL:
    def __init__(self, title, url, created_at):
        self.title = title
        self.url = url
        self.created_at = created_at


def xpath_soup(element):
    """
    Generate xpath of soup element
    :param element: bs4 text or node
    :return: xpath as string
    """
    components = []
    child = element if element.name else element.parent
    for parent in child.parents:
        """
        @type parent: bs4.element.Tag
        """
        previous = itertools.islice(parent.children, 0, parent.contents.index(child))
        xpath_tag = child.name
        xpath_index = sum(1 for i in previous if i.name == xpath_tag) + 1
        components.append(xpath_tag if xpath_index == 1 else '%s[%d]' % (xpath_tag, xpath_index))
        child = parent
    components.reverse()
    return '/%s' % '/'.join(components)


def rowReader(csv_file, index):
    a = csv_file
    with open(a, newline='', encoding="utf-8-sig") as b:
        reader = csv.reader(b)
        row = [row for idx, row in enumerate(reader) if idx in (index, index)]
        row = row[0]
        b.close()
        return row


def find_maintenance(soup, label):  # Poponik maintenance
    try:
        a = soup.find("h3", text=re.compile(label))
        if a.next_sibling.next_sibling is None:
            pass
        else:
            b = a.next_sibling.next_sibling
            return b
    except:
        return "Null"


def find_out_element(soup, label):  # Poponik attributes
    a = soup.find("strong", text=re.compile(label))
    if a.next_element.next_element is None:
        pass
    else:
        b = a.next_element.next_element
        return b


def find_out_element_1(soup, label):  # Poponik attributes
    a = soup.find("strong", text=re.compile(label))
    if a.next_element.next_element.next_element is None:
        pass
    else:
        b = a.next_element.next_element.next_element
        return b


def find_out_element_2(soup, label):  # Poponik attributes
    a = soup.find("strong", text=re.compile(label))
    if a.next_element is None:
        pass
    else:
        b = a.next_element
        return b


def find_out_element_3(soup, label):  # Poponik attributes
    a = soup.find("h3", text=re.compile(label))
    if a.next_element.next_element is None:
        pass
    else:
        b = a.next_element.next_element
        return b.text


def find_out_element_4(soup, label):  # Poponik attributes
    a = soup.find("p", text=re.compile(label))
    if a.next_element.next_element is None:
        pass
    else:
        b = a.next_element.next_element
        return b.text


def storeExceptions(exception_log, failure_log):
    try:
        with open(r'Exceptions/Exceptions.csv', 'a', newline='', encoding="utf-8-sig") as e_file:
            writer = csv.writer(e_file)
            writer.writerow([exception_log, failure_log, datetime.datetime.now()])
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(Red + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))


def replaceName(text, name):
    newText = re.sub(r"\b{}\b".format(name), "visitor", text)
    return str(newText)


def pushServer(product):  # based on object
    header = {"Content-Type": "application/x-www-form-urlencoded", "Content-Length": "length"}
    d = {'Token': "E3f%123Vn@o9", 'URL': product.url, 'Title': product.title, 'Price': product.price,
         'Description': product.description,
         'Categories': product.category,
         "ProductSpecs": product.product_attributes, "Attributes": product.product_spc, "Brand": product.brand,
         "Availability": product.availability,
         "Image": product.image_name, "ImageList": product.images_list_names, "SourceMainImage": product.image,
         "SourceImageList": product.images_list, "FeedbackCount": product.feedbacks,
         "FeedbackType": product.feedback_type}
    a = requests.post("https://nargil.ir/srv/srvdata.asmx/Products_Scraped_InsertUpdate", headers=header, data=d)
    print(a.content)


def pushServer2(product):  # based on csv file
    header = {"Content-Type": "application/x-www-form-urlencoded", "Content-Length": "length"}
    d = {'Token': "E3f%123Vn@o9", 'URL': product['URL'], 'Title': product['Title'], 'Price': product['Price'],
         'Description': product['Description'],
         'Categories': product['Category'],
         "ProductSpecs": product['Specifications'], "Attributes": product['Attributes'], "Brand": product['Brand'],
         "Availability": product['Availability'],
         "Image": product['Image_name'], "ImageList": product['Images_list_names'], "SourceMainImage": product['Image'],
         "SourceImageList": product['Images_list'], "FeedbackCount": product['FeedbackCount'],
         "FeedbackType": product['FeedbackType']}
    a = requests.post("https://nargil.ir/srv/srvdata.asmx/Products_Scraped_InsertUpdate", headers=header, data=d)
    print(a.text)


def csvToServer(csv_file, csv_id):
    my_list = []

    with open(csv_file, 'r', encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        for row in reader:
            my_list.append({'Title': row[0], 'Price': row[1], 'Image': row[2], 'Description': row[3], 'URL': row[4],
                            'Category': row[5], 'Images_list': row[6], 'Brand': row[7], 'Specifications': row[8],
                            'Maintenance': row[9], 'Attributes': row[10], 'Availability': row[11],
                            'Image_name': row[12], 'Images_list_names': row[13], 'FeedbackCount': row[14],
                            'FeedbackType': row[15]})

    del my_list[0]
    for i in range(csv_id - 2, len(my_list)):
        pushServer2(my_list[i])
        sleep(0.5)


def downloadImage(link, img_name, dst_path):
    CRED = '\033[91m'
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
        r = requests.get(link, headers=headers, allow_redirects=True)
        open(dst_path + '/' + img_name, 'wb').write(r.content)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(CRED + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))
        storeExceptions('Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno), link)


def downloadImages(lst, img_name_list, dst):
    CRED = '\033[91m'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
    try:
        for i in range(0, len(lst)):
            r = requests.get(img_name_list[i], headers=headers, allow_redirects=True)
            open(dst + '/' + lst[i], 'wb').write(r.content)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(CRED + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))
        storeExceptions('Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno), lst)


def imageNameConverter(url):
    CRED = '\033[91m'
    try:
        postfix = url[url.rindex('.') + 1:]
        postfix = postfix.strip()
        currentTime = datetime.datetime.now().strftime("%m-%d %H:%M:%S:%f")
        currentTime_str = re.sub(r':', '', currentTime)
        currentTime_str = re.sub(r'-', '', currentTime_str)
        currentTime_str = re.sub(r' ', '', currentTime_str)
        image_name = 'Nargil-' + currentTime_str + '.' + postfix
        return image_name
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(CRED + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))
        storeExceptions('Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno), url)


def imagesListConverter(lst):
    CRED = '\033[91m'
    try:
        images_names_list = []
        for i in range(0, len(lst)):
            postfix = lst[i][lst[i].rindex('.') + 1:]
            postfix = postfix.strip()
            imagesListCurrentTime = datetime.datetime.today() - datetime.timedelta(microseconds=-71)
            imagesListCurrentTime = imagesListCurrentTime.strftime("%m-%d %H:%M:%S:%f")
            currentTime_str = re.sub(r':', '', imagesListCurrentTime)
            currentTime_str = re.sub(r'-', '', currentTime_str)
            currentTime_str = re.sub(r' ', '', currentTime_str)
            image_name = 'Nargil-' + currentTime_str + '.' + postfix
            images_names_list.append(image_name)
            sleep(0.1)
        return images_names_list
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(CRED + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))
        storeExceptions('Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno), lst)


def flatten(lis):
    for item in lis:
        if isinstance(item, Iterable) and not isinstance(item, str):
            for x in flatten(item):
                yield x
        else:
            yield item


def remove_specific_row_from_csv(file, column_name, *args):
    '''
    :param file: file to remove the rows from
    :param column_name: The column that determines which row will be
           deleted (e.g. if Column == Name and row-*args
           contains "Gavri", All rows that contain this word will be deleted)
    :param args: Strings from the rows according to the conditions with
                 the column
    '''
    row_to_remove = []
    for row_name in args:
        row_to_remove.append(row_name)
    try:
        df = pd.read_csv(file)
        for row in row_to_remove:
            df = df[eval("df.{}".format(column_name)) != row]
            print(df)
        # df.to_csv(file, index=False)
    except Exception  as e:
        raise Exception("Error message....")


def linkChecker(csv_file, link):
    exist_status = 0
    csv_file = csv.reader(open(csv_file, "r", encoding="utf-8-sig"), delimiter=",")
    for row in csv_file:
        if row[4] == link:
            exist_status = 1
            break
        else:
            pass
    # print(exist_status)
    return exist_status


def linkChecker1(csv_file, link):
    exist_status = 0
    csv_file = csv.reader(open(csv_file, "r", encoding="utf-8-sig"), delimiter=",")
    for row in csv_file:
        if row[1] == link:
            exist_status = 1
            break
        else:
            pass
    # print(exist_status)
    return exist_status


def csvToDB(csv_file, csv_id):  # This function will insert all data of csv from csv_id to end
    import mysql.connector
    global row_count
    with open(csv_file, newline='', encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        row_count = sum(1 for row in reader) - 1
        f.close()

    for i in range(csv_id, row_count):
        con = mysql.connector.connect(user="root", password='', host="127.0.0.1", database='nargil_db')
        cursor = con.cursor()
        sql = "INSERT INTO products (Title,Price,Image,Description,URL,Category,Images_list,Brand,Specifications,Maintenance,Attributes,Availability,Image_name,Images_list_names,FeedbackCount,FeedbackType,Timestamp) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        val = (
            rowReader(r'Web_sites/Montakhab/products.csv', i)[0],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[1],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[2],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[3],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[4],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[5],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[6],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[7],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[8],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[9],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[10],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[11],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[12],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[13],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[14],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[15],
            rowReader(r'Web_sites/Montakhab/products.csv', i)[16],
        )
        cursor.execute(sql, val)
        con.commit()
        con.close()

        print(Blue + "The product with title of " + rowReader(r'Web_sites/Montakhab/products.csv', i)[
            0] + " successfully inserted to db")

    print(rowReader(r'Web_sites/Montakhab/products.csv', 1))


def csvRows(csv_file):
    with open(csv_file, newline='', encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        rows_count = sum(1 for row in reader) - 1
        f.close()
    return rows_count


def storeProduct(product, dst):
    CRED = '\033[91m'

    try:
        product.title = re.sub(r',', ' ', product.title)
        product.title = re.sub(r'"', ' ', product.title)
        product.description = re.sub(r",", ' ', product.description)
        product.description = re.sub(r'"', ' ', product.description)
        product.maintenance = re.sub(r',', ' ', product.maintenance)
        product.maintenance = re.sub(r'"', ' ', product.maintenance)

        product_specification = [product.title, product.price, product.image,
                                 product.description,
                                 product.url, product.category, product.images_list,
                                 product.brand,
                                 product.product_attributes, product.maintenance, product.product_spc,
                                 product.availability, product.image_name, product.images_list_names,
                                 product.feedbacks, product.feedback_type, product.created_at]

        with open(dst, 'a', newline='', encoding="utf-8-sig") as products_file:
            writer = csv.writer(products_file)
            writer.writerow(product_specification)
        print(Blue + "The product with title of " + str(title_purge) + " successfully scraped and stored")

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(CRED + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))
        storeExceptions('Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno), product.url)


def updateProduct(link, product, dst):
    try:
        df = pd.read_csv(dst)
        df.loc[df['URL'] == link, ['Title', 'Price', 'Image',
                                   'Description', 'Category', 'Images_list', 'Brand',
                                   'Specifications', 'Maintenance', 'Attributes',
                                   'Availability', 'FeedbackCount', 'FeedbackType', 'Timestamp']] = \
            [product.title, product.price, product.image, product.description, product.category, product.images_list,
             product.brand, product.product_spc, product.maintenance, product.product_attributes, product.availability,
             product.feedbacks, product.feedback_type, datetime.datetime.now()]
        df.to_csv(dst, index=False, encoding="utf-8-sig")
        print(Green + "The product with title of " + str(title_purge) + " successfully updated")

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(Red + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))
        storeExceptions('Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno), link)


def dkScraper(link):
    global title_purge
    global price_purge
    global image_link
    global description_purge
    global categories_purge
    global product_images_purge
    global brand_purge
    global product_attributes_purge
    global maintenance_purge
    global availability_purge
    global image_name_purge
    global images_list_names_purge
    global feedback_type

    images_list = []

    CRED = '\033[91m'
    CBLUE = '\33[94m'
    try:
        # ua = UserAgent()
        # header = {'User-Agent': str(ua.chrome)}

        options = Options()
        options.headless = True
        options.add_argument('-headless')
        options.add_argument("--window-size=1920,1200")

        driver = webdriver.Chrome(options=options, executable_path='C:/Python/chromedriver.exe')
        driver.implicitly_wait(0)
        driver.get(link)
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        # print(soup)
        title = soup.find("h1", {"class": "text-h4"})
        if title is None:
            title_purge = "Null"
        else:
            title_purge = title.text

        price = soup.find("span", {"class": "text-h4"})
        if price is None:
            price_purge = 0
        else:
            price_purge = re.sub(r',', '', price.text)
            price_purge = int(unidecode(str(price_purge)))

        description = soup.find("div", {"class": "text-body-1"})
        if description is None:
            description_purge = "Null"
        else:
            description_purge = description.text

        image = soup.find("div", {"class": "ml-4-lg"})
        if image is None:
            image_link = "Null"
        else:
            image = image.find("div", {"class": "d-none-lg"})
            image_link = image['data-main-image-src']

        url = link

        categories = soup.find("div", {"class": "swiper-wrapper"})
        if categories is None:
            categories_purge = "Null"
        else:
            categories = categories.text
            categories_list = categories.split("/")
            categories_list = categories_list[1:]
            categories_purge = categories_list
        categories_purge = str(categories_purge)

        images = soup.find_all("div", {"class": "pointer", "img": ""})
        if images is None:
            product_images_purge = "Null"
        else:
            for s in range(0, len(images)):
                # print(images[s])
                try:
                    images_list.append(images[s].find("div").find("img")['data-src'])
                    # print(images[s].find("div").find("img")['data-src'])
                except:
                    # print("error occurred in value "+str(s))
                    pass

            product_images_purge = str(images_list)

        brand = soup.find("p", {"class": "text-subtitle"})
        if brand is None:
            brand_purge = "Null"
        else:
            brand_purge = brand.text

        specifications = {}
        spc_keys = soup.find_all("p", {
            "class": "ml-4 text-body-1 color-500 py-2 py-3-lg p-2-lg shrink-0 Specification_specification__value__NQOYM"})
        spc_values = soup.find_all("p", {
            "class": "d-flex ai-center w-full text-body-1 color-900 break-words"})

        if spc_keys is None or spc_values is None:
            specifications = "Null"
        else:
            for i in range(0, len(spc_keys)):
                spc_keys[i] = spc_keys[i].text.strip().replace('\u200c', '')
                spc_values[i] = spc_values[i].text.strip().replace('\u200c', '')
                specifications[spc_keys[i]] = spc_values[i]

        specifications = str(specifications)

        maintenance_purge = "On description"

        attributes = soup.find("div", {"class": "border-t border-none-lg"})
        if attributes is None:
            product_attributes_purge = "Null"
        else:
            product_attributes_purge = str(attributes.text)

        availability = soup.find("div", {
            "class": "mb-2 text-center d-flex ai-center jc-center pos-relative color-500 notAvailable_buyBoxNotAvailable__headerTextLine__pIThr"})
        if availability is None:
            availability_purge = True
        else:
            availability_purge = False

        image_name_purge = imageNameConverter(image_link)
        image_name_purge = image_name_purge.partition('?')[0].strip()

        images_list_names_purge_list = imagesListConverter(images_list)
        for i in range(0, len(images_list_names_purge_list)):
            images_list_names_purge_list[i] = images_list_names_purge_list[i].partition('?')[0].strip()
        images_list_names_purge = str(images_list_names_purge_list)

        feedbacks = soup.find("p", {"class": "color-400 body-2 mr-2"})
        if feedbacks is None:
            feedbacks = 0
        else:
            feedbacks = [int(s) for s in feedbacks.text.strip().split() if s.isdigit()]
            feedbacks = feedbacks[0]

        if feedbacks == 0:
            feedback_type = 'None'
        else:
            feedback_type = "Rates"

        current_time = datetime.datetime.now()
        str_current_time = str(current_time)

        driver.quit()

        dkProduct = Product(title_purge, price_purge, image_link, description_purge, url, categories_purge,
                            product_images_purge, brand_purge,
                            specifications, maintenance_purge, product_attributes_purge, availability_purge,
                            image_name_purge, images_list_names_purge, feedbacks, feedback_type,
                            str_current_time)

        if linkChecker(r'Web_sites/Digikala/products.csv', dkProduct.url) == 0:
            storeProduct(dkProduct, 'Web_sites/Digikala/products.csv')
        else:
            updateProduct(dkProduct.url, dkProduct, 'Web_sites/Digikala/products.csv')
        pushServer(dkProduct)
        # downloadImage(dkProduct.image, dkProduct.image_name, 'Web_sites/Digikala/Image')
        # downloadImages(images_list_names_purge_list, images_list, 'Web_sites/Digikala/Images_list')

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(CRED + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))
        storeExceptions('Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno), link)


def storeDKURLS(url):
    CRED = '\033[91m'

    try:
        product_specification = [url.title, url.url, url.created_at]

        with open('Web_sites/Digikala/urls.csv', 'a', newline='', encoding="utf-8-sig") as products_file:
            writer = csv.writer(products_file)
            writer.writerow(product_specification)

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(CRED + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))


def fetchAllDigikala(category, page):  # Fetching dk products to urls.csv
    products_links = []

    category_list = ['category-house-plants', 'category-planting-supplies', 'category-gardening-tools']

    try:

        options = Options()
        options.headless = True
        options.add_argument('-headless')
        options.add_argument("--window-size=1920,1200")

        driver = webdriver.Chrome(options=options, executable_path='C:/Python/chromedriver.exe')
        driver.implicitly_wait(0)
        driver.get('https://www.digikala.com/search/' + str(category) + '/?page=' + str(page))
        soup = BeautifulSoup(driver.page_source, 'html.parser')

        last_page = soup.find_all("span", {"type": "button",
                                           "class": "d-flex w-9 h-9 jc-center ai-center radius-circle m-1 text-body2-strong pointer !hover:border border-r-700 pointer PageNumberButton_PageNumberButton__b455s"})
        last_page = unidecode(last_page[-1].text)
        try:
            last_page = int(last_page)
        except:
            last_page = "No last_page detected!"

        for i in range(page, last_page):
            try:
                driver.get('https://www.digikala.com/search/' + str(category) + '/?page=' + str(i))
                driver.implicitly_wait(2)
                sleep(2)

                soup = BeautifulSoup(driver.page_source, 'html.parser')
                products_of_page = soup.find_all("a", {
                    "class": "d-block pointer pos-relative bg-000 overflow-hidden grow-1 py-3 px-4 px-2-lg h-full-lg VerticalProductCard_VerticalProductCard--hover___3eXg"})
                if len(products_of_page) == 0:
                    driver.get('https://www.digikala.com/search/' + str(category) + '/?page=' + str(i))
                    driver.implicitly_wait(2)
                    sleep(2)
                    soup = BeautifulSoup(driver.page_source, 'html.parser')
                    products_of_page = soup.find_all("a", {
                        "class": "d-block pointer pos-relative bg-000 overflow-hidden grow-1 py-3 px-4 px-2-lg h-full-lg VerticalProductCard_VerticalProductCard--hover___3eXg"})

                    for l in range(0, len(products_of_page)):
                        products_links.append('https://www.digikala.com' + str(products_of_page[l]['href']))
                        date_time = datetime.datetime.now()
                        dk_url = URL(products_of_page[l].text,
                                     'https://www.digikala.com' + str(products_of_page[l]['href']), date_time)
                        storeDKURLS(dk_url)
                    print(products_links)
                    driver.implicitly_wait(2)

                else:
                    for l in range(0, len(products_of_page)):
                        products_links.append('https://www.digikala.com' + str(products_of_page[l]['href']))
                        date_time = datetime.datetime.now()
                        dk_url = URL(products_of_page[l].text,
                                     'https://www.digikala.com' + str(products_of_page[l]['href']), date_time)
                        storeDKURLS(dk_url)
                    print(products_links)
                    driver.implicitly_wait(2)

                # print(products_links)

            except:
                print("error occurred!")

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(Red + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))


def fetchAllDk(csv_file, csv_id):  # Complete fetching from urls.csv to products.csv
    global row_count

    s = csv_file
    with open(s, newline='', encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        row_count = sum(1 for row in reader) - 1
        f.close()

    for i in range(csv_id, row_count):
        link = str(rowReader(r'Web_sites/Digikala/urls.csv', i)[1])
        dkScraper(link)


def cafeGoldoonScraper(link):
    global title_purge
    global price_purge
    global color_purge
    global image_link
    global description_purge
    global categories_purge
    global brand_purge
    global product_attributes_purge
    global maintenance_purge
    global availability_purge
    global image_name_purge
    global images_list_names_purge

    categories_list = []
    product_attrs_dict = dict()

    CRED = '\033[91m'
    CBLUE = '\33[94m'
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
        r = requests.get(link, headers=headers)
        soup = BeautifulSoup(r.text, 'html.parser')
        title = soup.find("h1", {"class": "product_title"})
        if title is None:
            title_purge = "Null"
        else:
            title_purge = title.text

        price_in_content_list = []
        price = soup.find("p", {"class": "price"})
        if price is None:
            price_purge = 0
        else:
            try:
                price = price.find("bdi").text
                price_purge = re.sub(r'تومان', '', price)
                price_purge = re.sub(r',', '', price_purge)
                price_purge = int(price_purge)
            except:
                prices_in_content = soup.find_all("h5")
                prices_in_content = prices_in_content[:3]
                # print(prices_in_content)
                for i in range(0, len(prices_in_content)):
                    prices = prices_in_content[i].find_all("strong")
                    # print(prices[-1])
                    if "تومان" in prices[-1].text:
                        # print(prices[-1].text)
                        price_in_content_list.append(prices[-1].text)
                # print(prices_in_content)
                final_price = price_in_content_list[0]
                final_price = int(re.sub("تومان", "", final_price).strip())
                price_purge = final_price

        image = soup.find("figure", {"class": "woocommerce-product-gallery__image"})
        if image is None:
            image_link = "Null"
        else:
            image = image.find("a")
            image_link = image['href']

        description = soup.find("div", {"id": "tab-description"})
        if description is None:
            description_purge = "Null"
        else:
            description_purge = description.text

        url = link

        categories = soup.find_all("nav", {"class": "woocommerce-breadcrumb"})
        if categories is None:
            categories_purge = "Null"
        else:
            last_category = soup.find("span", {"class": "breadcrumb-last"})
            last_category = last_category.text
            categories_1 = categories[0].find_all("a")
            for i in range(0, len(categories_1)):
                categories_list.append(categories_1[i].text)

            categories_list.append(last_category)
            categories_purge = str(categories_list)

        images_list = []
        product_images_purge = str(images_list)

        brand_purge = 'cafegoldoon'

        product_attributes = soup.find("div", {"class": "woocommerce-product-details__short-description"})
        if product_attributes is None:
            product_attributes_purge = "Null"
        else:
            attrs = []
            all_attrs = product_attributes.find_all("p")
            for i in range(0, len(all_attrs)):
                result = re.split('[-:]', all_attrs[i].text)
                # print(result)
                if len(result) == 2:
                    attrs.append(result)
                else:
                    pass
            attrs = str(attrs)
            product_attributes_purge = attrs

        maintenance_purge = 'On description'

        specifications_dict = {}
        specifications_keys = []
        specifications_values = []
        values = soup.find_all("select")
        keys = soup.find_all("td", {"class": "label"})
        if values is None:
            specifications_dict = "Null"
        else:
            values = values[:len(keys)]
            for p in range(0, len(keys)):
                specifications_keys.append([keys[p].text.strip()])
            for q in range(0, len(values)):
                values[q] = re.sub(r'یک گزینه را انتخاب کنید', '', values[q].text.strip())
                specifications_values.append(values[q])

            for x in range(0, len(specifications_keys)):
                specifications_dict[str(specifications_keys[x])] = str(specifications_values[x])
            # print(specifications_dict)

            specifications_dict = str(specifications_dict)

        availability = soup.find("div", {"class": "product-images-inner"})
        if availability is None:
            availability_purge = "Null"
        else:
            availability = availability.findChildren("div", {"class": "product-labels"}, recursive=False)
            if len(availability) == 0:
                availability_purge = True
            else:
                availability_purge = False

        image_name_purge = imageNameConverter(image_link)
        images_list_names_purge_list = imagesListConverter(images_list)
        images_list_names_purge = str(images_list_names_purge_list)

        feedbacks = 0
        feedbacks_type = 'None'

        current_time = datetime.datetime.now()
        str_currentTime = str(current_time)[:19]

        cafegoldoonProduct = Product(title_purge, price_purge, image_link, description_purge, url,
                                     categories_purge, product_images_purge, brand_purge, product_attributes_purge,
                                     maintenance_purge, specifications_dict, availability_purge, image_name_purge,
                                     images_list_names_purge, feedbacks, feedbacks_type,
                                     str_currentTime)

        if linkChecker(r'Web_sites/Cafegoldoon/products.csv', cafegoldoonProduct.url) == 0:
            storeProduct(cafegoldoonProduct, 'Web_sites/Cafegoldoon/products.csv')
        else:
            updateProduct(cafegoldoonProduct.url, cafegoldoonProduct, 'Web_sites/Cafegoldoon/products.csv')
        pushServer(cafegoldoonProduct)
        # downloadImage(cafegoldoonProduct.image, cafegoldoonProduct.image_name, 'Web_sites/Cafegoldoon/Image')
        # downloadImages(images_list_names_purge_list, images_list, 'Web_sites/Cafegoldoon/Images_list')

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(CRED + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))
        storeExceptions('Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno), link)


def fetchAllCafeGoldoon():
    CRED = '\033[91m'
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
        while True:
            try:
                scrapeType = int(
                    input(
                        "For scraping as according to specifically category enter 1 or scraping all together enter 2: "))
                while scrapeType not in range(1, 3):
                    scrapeType = int(input("Enter 1 or 2: "))
                break
            except:
                print("That's not a valid value!")

        if scrapeType == 1:
            category = input(
                "Enter a category which you wanna scrape that data: (Valid categories are : گیاهان-آپارتمانی , درختچه-ها , هدایای-تبلیغاتی , زیورآلات-طبیعی , ملزومات-نگهداری-گیاه , داروخانه-گیاه-پزشکی , هدایای-مناسبتی ,فروش-عمده-گلدان-و-گیاه )")
            page = int(input("Enter the page number which wanna start from that page: "))
            while True:
                r1 = requests.get('https://cafegoldoon.com/product-category/' + str(category) + '/page/' + str(page),
                                  headers=headers)
                soup = BeautifulSoup(r1.text, 'html.parser')
                print('https://cafegoldoon.com/product-category/' + str(category) + '/page/' + str(page))
                products = soup.find_all("div", {"class": "product-grid-item"})
                page = page + 1
                if len(products) == 0:
                    break
                else:
                    for h in range(0, int(len(products))):
                        link = products[h].find("a")['href']
                        cafeGoldoonScraper(link)
            print("Products of page " + str(page) + "completed")

        elif scrapeType == 2:
            categories_dict = {
                1: 'https://cafegoldoon.com/product-category/%DA%AF%DB%8C%D8%A7%D9%87%D8%A7%D9%86-%D8%A2%D9%BE%D8%A7%D8%B1%D8%AA%D9%85%D8%A7%D9%86%DB%8C/page/',
                # گیاهان آپارتمانی
                2: 'https://cafegoldoon.com/product-category/%D8%A7%D9%86%D9%88%D8%A7%D8%B9-%DA%AF%DB%8C%D8%A7%D9%87%D8%A7%D9%86-%D8%A2%D9%BE%D8%A7%D8%B1%D8%AA%D9%85%D8%A7%D9%86%DB%8C/%D8%AF%D8%B1%D8%AE%D8%AA%DA%86%D9%87-%D9%87%D8%A7/page/',
                # درختچه ها
                3: 'https://cafegoldoon.com/product-category/%d9%87%d8%af%d8%a7%db%8c%d8%a7%db%8c-%d8%aa%d8%a8%d9%84%db%8c%d8%ba%d8%a7%d8%aa%db%8c/page/',
                # هدایای-تبلیغاتی
                4: 'https://cafegoldoon.com/product-category/%d8%b2%db%8c%d9%88%d8%b1%d8%a2%d9%84%d8%a7%d8%aa-%d8%b7%d8%a8%db%8c%d8%b9%db%8c/page/',
                # زیورآلات طبیعی
                5: 'https://cafegoldoon.com/product-category/%D9%85%D9%84%D8%B2%D9%88%D9%85%D8%A7%D8%AA-%D9%86%DA%AF%D9%87%D8%AF%D8%A7%D8%B1%DB%8C-%DA%AF%DB%8C%D8%A7%D9%87/page/',
                # ملزومات جانبی گیاه
                6: 'https://cafegoldoon.com/product-category/%D8%AF%D8%A7%D8%B1%D9%88%D8%AE%D8%A7%D9%86%D9%87-%DA%AF%DB%8C%D8%A7%D9%87-%D9%BE%D8%B2%D8%B4%DA%A9%DB%8C/page/',
                # داروخانه گیاه پزشکی
                7: 'https://cafegoldoon.com/product-category/%d9%87%d8%af%d8%a7%db%8c%d8%a7%db%8c-%d9%85%d9%86%d8%a7%d8%b3%d8%a8%d8%aa%db%8c/page/',
                # هدایا و مناسبت ها
                8: 'https://cafegoldoon.com/product-category/%D9%81%D8%B1%D9%88%D8%B4-%D8%B9%D9%85%D8%AF%D9%87-%DA%AF%D9%84%D8%AF%D8%A7%D9%86-%D9%88-%DA%AF%DB%8C%D8%A7%D9%87/page/'
                # فروش عمده گل و گیاه
            }
            print(len(categories_dict))
            for k in range(1, len(categories_dict)):
                l = 1
                while True:
                    # for k in range(1,len(categories_dict))
                    r1 = requests.get(str(categories_dict[k]) + str(l), headers=headers)
                    soup = BeautifulSoup(r1.text, 'html.parser')
                    products = soup.find_all("div", {"class": "product-grid-item"})
                    l = l + 1
                    if len(products) == 0:
                        break
                    else:
                        for h in range(0, int(len(products))):
                            link = products[h].find("a")['href']
                            cafeGoldoonScraper(link)
                print("Products" + str(k) + "completed")

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(CRED + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))


def golbamaScraper(link):
    global title_purge
    global price_purge
    global image_link
    global description_purge
    global categories_purge
    global brand_purge
    global specifications_purge
    global product_attributes_purge
    global maintenance_purge
    global availability_purge
    global image_name_purge
    global images_list_names_purge

    categories_list = []
    spc_list = []

    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
        r = requests.get(link, headers=headers)
        soup = BeautifulSoup(r.text, 'html.parser')
        title = soup.find("div", {"class": "main-ttlexp-m7"})
        title_purge = title.text.strip()

        price = soup.find("div", {"class": "puctn-m7"})
        if price is None:
            price_purge = 0
        else:
            price = price.text.strip()
            price = re.sub(r'تومان', '', price)
            price_purge = re.sub(r',', '', price)
            price_purge = int(price_purge)

        image = soup.find("div", {"class": "biitm-m7"})
        if image is None:
            image_link = "Null"
        else:
            image = image.find("img")
            image_link = 'https://golbama.com' + image['src']

        description = soup.find("div", {"class": "static-s1"})
        if description is None or description.text.strip() == '.':
            description_purge = "No description found"
        else:
            description_purge = description.text.strip()

        categories = soup.find("div", {"class": "bcin-n5"})
        categories = categories.find_all("li")

        for i in range(0, len(categories)):
            categories_list.append(categories[i].text.strip())
        categories_list.pop(0)
        categories_purge = str(categories_list)

        images_list = []
        product_images_purge = str(images_list)

        brand_purge = 'Golbama'

        specifications = soup.find("div", {"id": "collapseOne"})
        if specifications is None:
            specifications_purge = "Null"
        else:
            specifications = specifications.find_all("span")
            # print(specifications)
            for l in range(0, len(specifications)):
                spc_list.append(specifications[l].text.strip())

            k = spc_list[1::2]
            v = spc_list[::2]
            specifications_purge = str(dict(zip(k, v)))

        maintenance_purge = 'On description'

        product_attributes_purge = str({})

        availability = soup.find("div", {"class": "respd-s1"})
        availability = availability.find("span", {"class": "ttl-s1"})
        if availability.text.strip() == 'ناموجود':
            availability_purge = True
        else:
            availability_purge = False

        image_name_purge = imageNameConverter(image_link)
        images_list_names_purge = str(imagesListConverter(images_list))

        feedbacks = 0
        feedbacks_type = 'None'

        current_time = datetime.datetime.now()
        str_currentTime = str(current_time)[:19]

        golbamaProduct = Product(title_purge, price_purge, image_link, description_purge, link,
                                 categories_purge, product_images_purge, brand_purge, specifications_purge,
                                 maintenance_purge, product_attributes_purge, availability_purge, image_name_purge,
                                 images_list_names_purge, feedbacks, feedbacks_type,
                                 str_currentTime)

        # print(golbamaProduct.url)
        # print(golbamaProduct.url)
        if linkChecker(r'Web_sites/Golbama/products.csv', golbamaProduct.url) == 0:
            storeProduct(golbamaProduct, 'Web_sites/Golbama/products.csv')
        else:
            updateProduct(golbamaProduct.url, golbamaProduct, 'Web_sites/Golbama/products.csv')
        pushServer(golbamaProduct)
        # downloadImage(cafegoldoonProduct.image, cafegoldoonProduct.image_name, 'Web_sites/Cafegoldoon/Image')
        # downloadImages(images_list_names_purge_list, images_list, 'Web_sites/Cafegoldoon/Images_list')


    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(Red + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))
        storeExceptions('Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno), link)


def fetchAllGolbama():
    try:
        starting_page = int(input('Enter the page which you wanna start from that: '))

        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}

        r = requests.get('https://golbama.com/product/', headers=headers)
        soup = BeautifulSoup(r.text, 'html.parser')

        last_page = soup.find("ul", {"class": "pagination"})
        last_page = int(last_page.find_all('li')[-2].text)

        products_list = []

        for i in range(starting_page, last_page + 1):
            r1 = requests.get('https://golbama.com/category?page=' + str(i) + '&per-page=30', headers=headers)
            soup1 = BeautifulSoup(r1.text, 'html.parser')
            products = soup1.find_all('a', {"class": "bplnk-m7"})
            for l in range(0, len(products)):
                golbamaScraper(products[l]['href'])
                sleep(1)




    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(Red + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))


def divarScraper(link):
    global title_purge
    global price_purge
    global image_link
    global description_purge
    global categories_purge
    global brand_purge
    global specifications_purge
    global product_attributes_purge
    global maintenance_purge
    global availability_purge
    global image_name_purge
    global images_list_names_purge

    categories_list = []
    brand_list = []
    spc = dict()

    try:
        r = requests.get(link)
        soup = BeautifulSoup(r.text, 'html.parser')
        title = soup.find('h1', {"class": "kt-page-title__title kt-page-title__title--responsive-sized"})
        title_purge = title.text.strip()

        price = soup.find_all("div", {"class": "kt-base-row__end kt-unexpandable-row__value-box"})
        price = price[1].text
        if 'تومان' in price:
            price_purge = re.sub(r'تومان', '', price)
            price_purge = unidecode(re.sub(r'٬', '', price_purge))
        else:
            price_purge = 0

        image = soup.find("picture", {"class": "kt-image-block"})
        image = image.find("source")['srcset']
        if '?' in image:
            image_link = image.split("?")[0]
        else:
            image_link = image

        description = soup.find("p", {
            "class": "kt-description-row__text post-description kt-description-row__text--primary"})
        description_purge = description.text.strip()

        url = link

        categories = soup.find_all("li", {"class": "kt-breadcrumbs__item"})
        for i in range(0, len(categories)):
            categories_list.append(categories[i].text.strip())

        categories_list.pop(0)
        categories_purge = str(categories_list)

        images_list = []

        brand = soup.find("p", {"class": "kt-event-row__title kt-event-row__text"})
        if brand is not None:
            brand_list.append(brand.text)

        options = Options()
        options.headless = True
        options.add_argument('-headless')
        options.add_argument("--window-size=1920,1200")

        PROXY = "170.155.5.235"  # IP:PORT or HOST:PORT
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument('--proxy-server=%s' % PROXY)

        driver = webdriver.Firefox(executable_path='C:/Python/geckodriver.exe')

        driver.implicitly_wait(0)

        # PROXY = "185.24.233.208:80"  # free proxies sometimes don't work, I tried with netherland's proxy, and it worked
        # chrome_options = Options()  # here is the change
        # chrome_options.add_argument('--proxy-server=%s' % PROXY)
        # driver = webdriver.Chrome(executable_path='C:/Python/chromedriver.exe', options=chrome_options)
        # driver.get("https://whatismyipaddress.com")  # and here is the change, just https

        driver.get(link)

        driver.delete_all_cookies()
        driver.refresh()

        driver.add_cookie({'name': 'token',
                           'value': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoiMDkwMTIzNzA1OTMiLCJpc3MiOiJhdXRoIiwiaWF0IjoxNjQ5NjU1Mjc1LCJleHAiOjE2NTA5NTEyNzUsInZlcmlmaWVkX3RpbWUiOjE2NDk2NTUyNzUsInVzZXItdHlwZSI6InBlcnNvbmFsIiwidXNlci10eXBlLWZhIjoiXHUwNjdlXHUwNjQ2XHUwNjQ0IFx1MDYzNFx1MDYyZVx1MDYzNVx1MDZjYyIsInNpZCI6ImFmNDNkNjQ4LWE3YTktNDlhOS04NGYyLTZlNjQwNWY3YTQ1MyJ9.8UWQKvztJPGOEiqc5kwErp3l85H_aVnjCpT8uX4fXgU',
                           'Domain': 'divar.ir', 'Path': '/', 'size': 386})

        driver.refresh()

        time.sleep(2)

        a = driver.find_element_by_css_selector("button.post-actions__get-contact")
        a.click()
        time.sleep(3)
        b = driver.find_element_by_css_selector("footer.kt-modal__actions")
        b1 = b.find_element_by_css_selector('button.kt-button--primary')
        b1.click()
        time.sleep(3)
        wait = WebDriverWait(driver, 3)
        element = wait.until(EC.presence_of_element_located((By.CLASS_NAME, "expandable-box")))
        time.sleep(3)
        html_source = element.get_attribute('innerHTML')
        soup2 = BeautifulSoup(html_source, 'html.parser')
        phone_number = soup2.find("a", {"class": "kt-unexpandable-row__action"})
        phone_number = unidecode(phone_number.text)
        print(phone_number)

        brand_list.append(phone_number)
        brand_purge = str(brand_list)

        specifications = soup.find_all("div", {"class": "kt-base-row kt-base-row--large kt-unexpandable-row"})
        for l in range(0, len(specifications)):
            key = specifications[l].find("p", {"class": "kt-base-row__title kt-unexpandable-row__title"}).text.strip()
            value = specifications[l].find("p", {"class": "kt-unexpandable-row__value"}).text.strip()
            spc[key] = value

        specifications_purge = str(spc)

        maintenance_purge = 'On description'

        product_attributes_purge = str({})

        availability_purge = True

        image_name_purge = imageNameConverter(image_link)
        images_list_names_purge = str(imagesListConverter(images_list))

        feedbacks = 0
        feedbacks_type = 'None'

        current_time = datetime.datetime.now()
        str_currentTime = str(current_time)[:19]

        divarProduct = Product(title_purge, price_purge, image_link, description_purge, link,
                               categories_purge, str(images_list), brand_purge, specifications_purge,
                               maintenance_purge, product_attributes_purge, availability_purge, image_name_purge,
                               images_list_names_purge, feedbacks, feedbacks_type,
                               str_currentTime)

        if linkChecker(r'Web_sites/Divar/products.csv', divarProduct.url) == 0:
            storeProduct(divarProduct, 'Web_sites/Divar/products.csv')
        else:
            updateProduct(divarProduct.url, divarProduct, 'Web_sites/Divar/products.csv')
        pushServer(divarProduct)


    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(Red + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))
        storeExceptions('Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno), link)


class Sel(unittest.TestCase):
    import warnings

    warnings.filterwarnings("ignore")

    def __init__(self, methodName: str = ...):
        super().__init__(methodName)
        self.driver = webdriver.Chrome(executable_path='C:/Python/chromedriver.exe')

    def setUp(self):
        self.driver.implicitly_wait(30)
        self.base_url = "https://divar.ir/"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_sel(self):
        driver = self.driver
        delay = 3
        cities = ['mianeh', 'tabriz', 'urmia', 'ardabil', 'isfahan', 'karaj', 'ilam', 'tehran', 'mashhad', 'ahvaz',
                  'shiraz',
                  'arak', 'kerman', 'gorgan', 'sari', 'rasht', 'hamedan', 'zanjan']
        for city in cities:
            driver.get(self.base_url + "s/" + str(city) + "/natural-plants")
            driver.refresh()
            i = 1
            while True:
                self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                height = driver.execute_script("return document.body.scrollHeight")
                time.sleep(4)
                products = driver.find_elements_by_class_name(
                    "kt-post-card.kt-post-card--outlined.kt-post-card--has-chat")
                # print(len(products))
                for l in range(0, len(products)):
                    title = products[l].find_element_by_class_name("kt-post-card__title").text
                    href = products[l].get_attribute("href")
                    timestamp = datetime.datetime.now()
                    urlObject = URL(title, href, timestamp)
                    if linkChecker1(r'Web_sites/Divar/urls.csv', urlObject.url) == 0:
                        storeDivarURLS(urlObject)
                    else:
                        pass
                new_height = driver.execute_script("return document.body.scrollHeight")
                if new_height == height:
                    break
                else:
                    continue
        html_source = driver.page_source
        data = html_source.encode('utf-8')


def fetchDivarURLS():
    try:
        if __name__ == "__main__":
            unittest.main()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(Red + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))


def fetchAllDivar(csv_file, csv_id):  # Complete fetching from urls.csv to products.csv
    global row_count

    s = csv_file
    with open(s, newline='', encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        row_count = sum(1 for row in reader) - 1
        f.close()

    for i in range(csv_id, row_count):
        link = str(rowReader(r'Web_sites/Divar/urls.csv', i)[1])
        divarScraper(link)


def storeDivarURLS(url):
    CRED = '\033[91m'

    try:
        product_specification = [url.title, url.url, url.created_at]

        with open('Web_sites/Divar/urls.csv', 'a', newline='', encoding="utf-8-sig") as products_file:
            writer = csv.writer(products_file)
            writer.writerow(product_specification)

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(CRED + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))


def mainFunction():
    global digikala_selection
    CRED = '\033[91m'
    try:
        print("Which website do you want to scrape?")
        sitesList = {1: 'Montakhab', 2: 'Iranderakht', 3: 'Golsetan', 4: 'Poponik', 5: 'BFC', 6: 'Anguor',
                     7: 'Digikala'}
        for key, value in sitesList.items():
            print(key, '-', value)

        while True:
            try:
                selection = int(input("Enter the website No whom you want to scrape: "))
                while selection not in range(1, len(sitesList) + 1):
                    selection = int(input("Enter website Number correctly: "))
                break
            except:
                print("That's not a valid value!")

        if selection == 1:
            print("You selected (Montakhab) website to scrape. if you want to fetch specific product, Enter 1 or "
                  "want to fetch all products, enter 2")
            while True:
                try:
                    scrapeType = int(input("Enter 1 or 2: "))
                    while scrapeType not in range(1, 3):
                        scrapeType = int(input("Enter 1 or 2: "))
                    break
                except:
                    print("That's not a valid value!")

            if scrapeType == 1:
                url = input("Enter product URL to scrape: ")
                while url.isnumeric():
                    url = input("Wrong input, Enter product URL carefully: ")
                while True:
                    if re.search('https://montakhab.co/product/', url):
                        montakhabScraper(url)
                        break
                    else:
                        print("Seems it's not montakhab product url")
                        url = input("Enter product URL to scrape: ")
            elif scrapeType == 2:
                fetchAllMontakhab()
        elif selection == 2:
            print("You selected (Iranderakht) website to scrape. if you want to fetch specific product, Enter 1 or "
                  "want to fetch all products, enter 2")
            while True:
                try:
                    scrapeType = int(input("Enter 1 or 2: "))
                    while scrapeType not in range(1, 3):
                        scrapeType = int(input("Enter 1 or 2: "))
                    break
                except:
                    print("That's not a valid value!")
            if scrapeType == 1:
                url = input("Enter product URL to scrape: ")
                while url.isnumeric():
                    url = input("Wrong input, Enter product URL carefully: ")
                while True:
                    if re.search('https://iranderakht.com/product/', url):
                        iranderakhtScraper(url)
                        break
                    else:
                        print("Seems it's not iranderakht product url")
                        url = input("Enter product URL to scrape: ")
            elif scrapeType == 2:
                fetchAllIranderakht()

        elif selection == 3:
            print("You selected (Golsetan) website to scrape. if you want to fetch specific product, Enter 1 or "
                  "want to fetch all products, enter 2")
            while True:
                try:
                    scrapeType = int(input("Enter 1 or 2: "))
                    while scrapeType not in range(1, 3):
                        scrapeType = int(input("Enter 1 or 2: "))
                    break
                except:
                    print("That's not a valid value!")

            if scrapeType == 1:
                url = input("Enter product URL to scrape: ")
                while url.isnumeric():
                    url = input("Wrong input, Enter product URL carefully: ")
                while True:
                    if re.search('https://www.golsetan.com/product/', url):
                        golsetanScraper(url)
                        break
                    else:
                        print("Seems it's not golsetan product url")
                        url = input("Enter product URL to scrape: ")
            elif scrapeType == 2:
                fetchAllGolsetan()

        elif selection == 4:
            print("You selected (Poponik) website to scrape. if you want to fetch specific product, Enter 1 or "
                  "want to fetch all products, enter 2")
            while True:
                try:
                    scrapeType = int(input("Enter 1 or 2: "))
                    while scrapeType not in range(1, 3):
                        scrapeType = int(input("Enter 1 or 2: "))
                    break
                except:
                    print("That's not a valid value!")

            if scrapeType == 1:
                url = input("Enter product URL to scrape: ")
                while url.isnumeric():
                    url = input("Wrong input, Enter product URL carefully: ")
                while True:
                    if re.search('https://poponik.com/product/', url):
                        poponikScraper(url)
                        break
                    else:
                        print("Seems it's not poponik product url")
                        url = input("Enter product URL to scrape: ")
            elif scrapeType == 2:
                fetchAllPoponik()

        elif selection == 5:
            print("You selected (BFC) website to scrape. if you want to fetch specific product, Enter 1 or "
                  "want to fetch all products, enter 2")
            while True:
                try:
                    scrapeType = int(input("Enter 1 or 2: "))
                    while scrapeType not in range(1, 3):
                        scrapeType = int(input("Enter 1 or 2: "))
                    break
                except:
                    print("That's not a valid value!")

            if scrapeType == 1:
                url = input("Enter product URL to scrape: ")
                while url.isnumeric():
                    url = input("Wrong input, Enter product URL carefully: ")
                while True:
                    if re.search('https://bfc.ir/Product/', url):
                        bfcScraper(url)
                        break
                    else:
                        print("Seems it's not BFC product url")
                        url = input("Enter product URL to scrape: ")
            elif scrapeType == 2:
                fetchAllBFC()
        if selection == 6:
            print("You selected (Anguor) website to scrape. if you want to fetch specific product, Enter 1 or "
                  "want to fetch all products, enter 2")
            while True:
                try:
                    scrapeType = int(input("Enter 1 or 2: "))
                    while scrapeType not in range(1, 3):
                        scrapeType = int(input("Enter 1 or 2: "))
                    break
                except:
                    print("That's not a valid value!")

            if scrapeType == 1:
                url = input("Enter product URL to scrape: ")
                while url.isnumeric():
                    url = input("Wrong input, Enter product URL carefully: ")
                while True:
                    if re.search('https://anguor.com/p/', url):
                        anguorScraper(url)
                        break
                    else:
                        print("Seems it's not Anguor product url")
                        url = input("Enter product URL to scrape: ")
            elif scrapeType == 2:
                fetchAllAnguor()
        if selection == 7:
            digikala_categories = {1: 'seeds'}
            for key, value in digikala_categories.items():
                print(key, '-', value)
            while True:
                try:
                    digikala_selection = int(input("Enter the category of digikala what you want to scraper: "))
                    if digikala_selection in range(1, len(digikala_categories) + 1):
                        break
                    else:
                        while digikala_selection not in range(1, len(digikala_categories) + 1):
                            raise Exception()
                except:
                    print("Wrong value. Enter correct value as written in pattern")
            if digikala_selection == 1:
                while True:
                    try:
                        scrapeType = int(
                            input("For scraping specific product enter 1 or scrape all products enter 2: "))
                        while scrapeType not in range(1, 3):
                            scrapeType = int(input("Enter 1 or 2: "))
                        break
                    except:
                        print("That's not a valid value!")

                if scrapeType == 1:
                    url = input("Enter product URL to scrape: ")
                    while url.isnumeric():
                        url = input("Wrong input, Enter product URL carefully: ")
                    while True:
                        if re.search('https://www.digikala.com/product/', url):
                            print("Correct value")
                            break
                        else:
                            print("Seems it's not Digikala product url")
                            url = input("Enter product URL to scrape: ")
                elif scrapeType == 2:
                    print("Fetching all digikala products")

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        print(CRED + '\033[1m' + 'Error occurred : ' + str(e) + 'in line ' + str(exc_tb.tb_lineno))


# mainFunction()

#.
#.
#.
#.
#.
#.
#.
#.
#.
#.
#.
#.
#.
#.